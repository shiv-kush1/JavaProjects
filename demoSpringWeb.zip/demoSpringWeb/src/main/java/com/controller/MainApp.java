package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.model.User;
import com.service.UserService;

@Controller
@RequestMapping("/myapp")
public class MainApp {
     @Autowired
	public UserService us;
	
   
	
	@RequestMapping(value="/welcome", method=RequestMethod.GET)
	@ResponseBody
	public String mainWelcome() {
		
		return "Welcome to spring MVC App";
	}
	
	
	
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	@ResponseBody
	public String loginValid(@RequestParam("uname")String name,@RequestParam("pass")String pass) {
	
		if(us.loginValid(name, pass)) {
			
			return "login success";
			
		}
		
	return "login failure";
	
}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
@ResponseBody
  public String registerUser(@RequestParam("uname")String name,@RequestParam("pass")String pass,@RequestParam("email")String email,@RequestParam("city")String city) {
		
		us.addUser(name,email,pass,city);
		
		return "register succesfully";
	}
}
